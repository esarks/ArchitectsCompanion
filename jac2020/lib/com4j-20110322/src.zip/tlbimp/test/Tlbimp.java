
import com4j.tlbimp.driver.Main;

/**
 * Debug driver.
 *
 * @author Kohsuke Kawaguchi
 */
public class Tlbimp {
    public static void main(String[] args) {
        Main.main(args);
    }
}
