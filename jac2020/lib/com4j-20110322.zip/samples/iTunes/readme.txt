iTunes comes with a COM API to programatically control it.
This sample shows how you can use that API.

For more information, see http://developer.apple.com/sdk/#iTunesCOM
