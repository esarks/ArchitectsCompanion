Sample that shows how to use com4j in conjunction with Java Web Start.
